# Enable Web Analytics

## Supported Providers

_in alphabetic order_

-   [Application Insights](https://azure.com/) - [documentation](/docs/analytics/applicationinsights.md)
-   [Baidu Analytics](https://tongji.baidu.com/) - [documentation](/docs/analytics/baidu.md)
-   [Clicky](https://clicky.com/) - [documentation](/docs/analytics/clicky.md)
-   [Cloudflare](https://www.cloudflare.com/analytics/) - [documentation](/docs/analytics/cloudflare.md)
-   [Counter.dev](https://counter.dev/) - [documentation](/docs/analytics/counterdev.md)
-   [Google Analytics](https://developers.google.com/analytics) - [documentation](/docs/analytics/googleanalytics.md)
-   [Google Tag Manager](https://developers.google.com/tag-manager) - [documentation](/docs/analytics/googletagmanager.md)
-   [Fathom Analytics](https://usefathom.com/) - [documentation](/docs/analytics/fathom.md)
-   [Goat Counter](https://www.goatcounter.com/) - [documentation](/docs/analytics/goatcounter.md)
-   [Matomo](https://matomo.org/) - [documentation](/docs/analytics/matomo.md)
-   [Micro Analytics](https://microanalytics.io/) - [documentation](/docs/analytics/microanalytics.md)
-   [One Dollars Stats](https://onedollarstats.com/analytics) - [documentation](/docs/analytics/onedollarstats.md)
-   [Pirsch](https://pirsch.io/) - [documentation](/docs/analytics/pirsch.md)
-   [Plausible Analytics](https://plausible.io/) - [documentation](/docs/analytics/plausible.md)
-   [Umami](https://umami.is/) - [documentation](/docs/analytics/umami.md)
-   [Vercel Analytics](https://vercel.com/analytics) - [documentation](/docs/analytics/vercel.md)
-   [Wide Angle Analytics](https://wideangle.co/) - [documentation](/docs/analytics/wideangle.md)